from flask import Flask, render_template, jsonify, request
import sqlite3
import random
import os

app = Flask(__name__)

def init_db():
    # 파일이 이미 존재하면 연결만 하고, 없으면 새로 생성함
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    
    # [중요] DROP TABLE을 삭제하고 CREATE TABLE IF NOT EXISTS를 사용
    # 이렇게 하면 기존 데이터가 있어도 테이블을 새로 만들지 않고 유지함
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            temp REAL,
            speed REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 데이터가 하나도 없을 때만 초기값(기본 15개)을 넣어줌
    cursor.execute('SELECT COUNT(*) FROM telemetry')
    if cursor.fetchone()[0] == 0:
        temp = 26.0
        for _ in range(15):
            temp += 0.1
            cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', 
                           (round(temp, 1), 0.5))
        conn.commit()
        
    conn.close()

# 서버 시작 시 DB 체크
init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/telemetry')
def get_telemetry():
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT temp FROM telemetry ORDER BY timestamp DESC LIMIT 1')
    last_temp = cursor.fetchone()[0]
    
    # 온도는 24~28도 사이를 유지하도록 보정
    new_temp = round(last_temp + random.uniform(-0.3, 0.3), 1)
    if new_temp > 28: new_temp = 27.5
    if new_temp < 24: new_temp = 24.5
    
    # 속도는 0.2 ~ 1.5 사이 랜덤 (막대 높이 확보)
    new_speed = round(random.uniform(0.2, 1.5), 2)
    
    cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', (new_temp, new_speed))
    conn.commit()
    conn.close()

    return jsonify({
        "temp": new_temp,
        "speed": new_speed,
        "battery": random.randint(95, 98),
        "cpu": random.randint(10, 15),
        "memory": random.randint(30, 33)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)