/**
 * Narchon FMS Dashboard - Main Control Script
 */

const robotState = {
    x: 150,      
    y: 150,      
    step: 25,    
    battery: 85,
    temp: 36.5
};

document.addEventListener('DOMContentLoaded', () => {
    const robotMarker = document.getElementById('robot-1');
    const mapContainer = document.querySelector('.map-zone');
    
    // 버튼 요소 매칭 (가운데 버튼 포함)
    const controls = {
        'up': document.querySelector('.btn-up'),
        'down': document.querySelector('.btn-down'),
        'left': document.querySelector('.btn-left'),
        'right': document.querySelector('.btn-right'),
        'center': document.querySelector('.btn-center'), 
        'turnL': document.querySelector('.btn-turnL'),
        'turnR': document.querySelector('.btn-turnR')
    };

    function updateRobotPosition() {
        if (!robotMarker || !mapContainer) return;

        const markerWidth = robotMarker.clientWidth || 40;
        const markerHeight = robotMarker.clientHeight || 40;
        const mapWidth = mapContainer.clientWidth;
        const mapHeight = mapContainer.clientHeight;

        robotState.x = Math.max(0, Math.min(robotState.x, mapWidth - markerWidth));
        robotState.y = Math.max(0, Math.min(robotState.y, mapHeight - markerHeight));

        robotMarker.style.left = `${robotState.x}px`;
        robotMarker.style.top = `${robotState.y}px`;
        robotMarker.style.position = 'absolute';
    }

    // 중앙 이동 함수
    window.moveToCenter = function() {
        if (!robotMarker || !mapContainer) return;
        
        // 맵 중심 좌표 계산 (맵 크기 절반 - 로봇 크기 절반)
        robotState.x = (mapContainer.clientWidth / 2) - (robotMarker.clientWidth / 2);
        robotState.y = (mapContainer.clientHeight / 2) - (robotMarker.clientHeight / 2);
        
        updateRobotPosition();
        addLog('RemoteControl', 'MOVE_CENTER', 'Admin');
    };

    window.moveRobot = function(direction) {
        switch(direction) {
            case 'up':    robotState.y -= robotState.step; break;
            case 'down':  robotState.y += robotState.step; break;
            case 'left':  robotState.x -= robotState.step; break;
            case 'right': robotState.x += robotState.step; break;
        }
        updateRobotPosition();
        addLog('RemoteControl', `MOVE_${direction.toUpperCase()}`, 'Admin');
    };

    // 이벤트 바인딩
    if (controls.up)    controls.up.onclick = () => moveRobot('up');
    if (controls.down)  controls.down.onclick = () => moveRobot('down');
    if (controls.left)  controls.left.onclick = () => moveRobot('left');
    if (controls.right) controls.right.onclick = () => moveRobot('right');
    
    // 가운데 버튼 클릭 시 이동
    if (controls.center) {
        controls.center.onclick = () => moveToCenter();
    }

    updateRobotPosition();
});

function addLog(scenario, activity, name) {
    const logTbody = document.getElementById('log-tbody');
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ko-KR', { hour12: false });

    if (logTbody) {
        if (logTbody.rows.length === 1 && logTbody.rows[0].cells.length === 1) logTbody.innerHTML = '';
        const row = `<tr><td>${timeStr}</td><td>${scenario}</td><td>${activity}</td><td>${name}</td><td>🔍</td></tr>`;
        logTbody.insertAdjacentHTML('afterbegin', row);
        if (logTbody.rows.length > 10) logTbody.deleteRow(-1);
    }
}