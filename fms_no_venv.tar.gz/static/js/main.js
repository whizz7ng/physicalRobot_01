const socket = io();

// 1. 로봇 전역 상태 관리 (위치 및 화면 표시용 가짜 속도)
window.robotState = {
    x: 0, y: 0,
    step: 25,
    currentSpeed: 0.0 
};

document.addEventListener('DOMContentLoaded', () => {
    const robotMarker = document.getElementById('robot-1');
    const mapContainer = document.querySelector('.map-zone');

    // 화면에 로봇 위치 반영
    const updatePosition = () => {
        if (!robotMarker) return;
        robotMarker.style.left = `${window.robotState.x}px`;
        robotMarker.style.top = `${window.robotState.y}px`;
    };

    // 로봇을 지도의 정중앙으로 배치
    const setCenter = () => {
        if (!robotMarker || !mapContainer) return;
        window.robotState.x = (mapContainer.clientWidth / 2) - (robotMarker.clientWidth / 2);
        window.robotState.y = (mapContainer.clientHeight / 2) - (robotMarker.clientHeight / 2);
        updatePosition();
        addLog('System', 'CENTER_ALIGN', 'Admin');
    };

    // 2. 이동 함수: 조작 시에만 가짜 속도(currentSpeed) 발생
    window.moveRobot = (direction) => {
        // 1. 지도와 로봇의 현재 크기 파악
        const robotMarker = document.getElementById('robot-1');
        const mapContainer = document.querySelector('.map-zone');
        if (!robotMarker || !mapContainer) return;

        const mapW = mapContainer.clientWidth;
        const mapH = mapContainer.clientHeight;
        const robotW = robotMarker.clientWidth;
        const robotH = robotMarker.clientHeight;

        // 2. 속도 발생 (시각 효과)
        window.robotState.currentSpeed = parseFloat((Math.random() * 0.8 + 0.7).toFixed(2));
        
        // 3. 임시 좌표 계산 (이동하기 전 미리 계산)
        let nextX = window.robotState.x;
        let nextY = window.robotState.y;

        switch(direction) {
            case 'up':    nextY -= window.robotState.step; break;
            case 'down':  nextY += window.robotState.step; break;
            case 'left':  nextX -= window.robotState.step; break;
            case 'right': nextX += window.robotState.step; break;
            case 'stop':  window.robotState.currentSpeed = 0.0; return;
        }

        // 4. [핵심] 경계 검사 (Boundary Check)
        // 0보다 작아지거나, 지도 크기에서 로봇 크기를 뺀 값보다 커지지 않게 제한
        if (nextX >= 0 && nextX <= (mapW - robotW)) {
            window.robotState.x = nextX;
        } else {
            addLog('System', 'WALL_DETECTED', 'R1'); // 벽 충돌 로그
        }

        if (nextY >= 0 && nextY <= (mapH - robotH)) {
            window.robotState.y = nextY;
        } else {
            addLog('System', 'WALL_DETECTED', 'R1');
        }

        // 5. 실제 위치 반영 및 로그 출력
        updatePosition();
        addLog('ManualControl', `MOVE_${direction.toUpperCase()}`, 'User_1');

        setTimeout(() => { window.robotState.currentSpeed = 0.0; }, 400);
    };

    // 3. 소켓 수신 (아두이노 조이스틱 연동)
    socket.on('serial_data', (data) => {
        const threshold = 300;
        if (data.joyY > 512 + threshold) moveRobot('up');
        else if (data.joyY < 512 - threshold) moveRobot('down');
        else if (data.joyX < 512 - threshold) moveRobot('left');
        else if (data.joyX > 512 + threshold) moveRobot('right');
    });

    // 4. 버튼 이벤트 바인딩 (footer.html의 클래스명과 일치시킴)
    const bindClick = (selector, direction) => {
        const btn = document.querySelector(selector);
        if (btn) btn.onclick = () => moveRobot(direction);
    };

    bindClick('.btn-up', 'up');
    bindClick('.btn-down', 'down');
    bindClick('.btn-left', 'left');
    bindClick('.btn-right', 'right');
    bindClick('.btn-turnL', 'left');  // 회전 버튼도 우선 이동 로직에 포함
    bindClick('.btn-turnR', 'right'); // 회전 버튼도 우선 이동 로직에 포함
    
    // 중앙 버튼 클릭 시 초기화
    const centerBtn = document.querySelector('.btn-center');
    if (centerBtn) centerBtn.onclick = setCenter;

    // 초기 배치 실행
    setTimeout(setCenter, 100);
});

// 5. 실시간 로그 출력 함수
function addLog(scenario, activity, name) {
    const logTbody = document.getElementById('log-tbody');
    if (!logTbody) return;

    const now = new Date();
    const timeStr = now.getFullYear() + '.' + 
                    (now.getMonth()+1).toString().padStart(2, '0') + '.' + 
                    now.getDate().toString().padStart(2, '0') + ' ' + 
                    now.toLocaleTimeString('ko-KR', { hour12: false });

    const row = `
        <tr>
            <td style="font-size: 11px;">${timeStr}</td>
            <td>${scenario}</td>
            <td style="color: #3b82f6; font-weight: 600;">${activity}</td>
            <td>${name}</td>
            <td>✅</td>
        </tr>
    `;

    logTbody.insertAdjacentHTML('afterbegin', row);

    // 로그 개수 제한 (최신 10개)
    if (logTbody.rows.length > 10) {
        logTbody.deleteRow(-1);
    }
}