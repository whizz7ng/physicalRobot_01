from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO
import sqlite3
import random
import threading
import serial
import time

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# --- [1] DB 초기화 (변동 없음) ---
def init_db():
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            temp REAL,
            speed REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('SELECT COUNT(*) FROM telemetry')
    if cursor.fetchone()[0] == 0:
        cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', (25.0, 0.0))
        conn.commit()
    conn.close()

init_db()

# --- [2] 아두이노 시리얼 통신 (실제 온도만 INSERT) ---
def read_serial():
    try:
        #ser = serial.Serial('COM7', 9600, timeout=1) # 본인 포트로 수정
        
        ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)
        print("✅ Arduino Connected")
    except:
        ser = None
        print("⚠️ Arduino Not Found")

    while True:
        if ser and ser.in_waiting > 0:
            try:
                line = ser.readline().decode('utf-8').strip()
                parts = line.split(',')
                if len(parts) == 3:
                    temp, joyX, joyY = float(parts[0]), int(parts[1]), int(parts[2])

                    # 실제 데이터 저장 (속도는 0.0으로 저장)
                    conn = sqlite3.connect('robot_data.db')
                    cursor = conn.cursor()
                    cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', (temp, 0.0))
                    conn.commit()
                    conn.close()

                    # 실시간 전송
                    socketio.emit('serial_data', {'temp': temp, 'joyX': joyX, 'joyY': joyY})
            except: pass
        time.sleep(0.1)

threading.Thread(target=read_serial, daemon=True).start()

# --- [3] 웹 API (DB 조회 전용) ---
@app.route('/api/telemetry')
def get_telemetry():
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT temp FROM telemetry ORDER BY timestamp DESC LIMIT 1')
    row = cursor.fetchone()
    conn.close()

    return jsonify({
        "temp": row[0] if row else 25.0,
        "battery": random.randint(95, 96), # 상태 정보는 랜덤 유지
        "cpu": random.randint(10, 15),
        "memory": random.randint(30, 33)
    })

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5001, debug=True)